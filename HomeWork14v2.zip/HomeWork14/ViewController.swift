//
//  ViewController.swift
//  HomeWork10
//
//  Created by Алексей Ильиных on 06.01.2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.pushViewController(LoadingController(), animated: false)
//        self.navigationController?.pushViewController(ViewController1(), animated: false)
    }


}

