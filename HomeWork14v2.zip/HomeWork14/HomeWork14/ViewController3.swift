//
//  ViewController3.swift
//  HomeWork12
//
//  Created by Алексей Ильиных on 06.01.2023.
//

import Foundation
import UIKit

final class ViewController3: UIViewController {
    let presenter = ViewController3Presenter()
    
    private var field1: UITextField!
    private var field2: UITextField!
    private var res: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        navigationItem.title = "Diff"
        
        let stack = UIStackView()
        stack.axis = .vertical
        stack.put(on: view)
        
        let label = UILabel()
        label.text = "Введите два числа - получите разницу"
        label.textAlignment = .center
        label.numberOfLines = 0
        
        stack.addArrangedSubview(label)
        
        let hStack = UIStackView()
        hStack.distribution = .fillEqually
        hStack.isLayoutMarginsRelativeArrangement = true
        hStack.layoutMargins = .init(top: 8, left: 20, bottom: 8, right: 20)
        hStack.spacing = 20
        
        field1 = UITextField()
        field1.backgroundColor = .red
        field1.borderStyle = .line
        field1.keyboardType = .numberPad
        
        field2 = UITextField()
        field2.backgroundColor = .blue
        field2.borderStyle = .line
        field2.keyboardType = .numberPad
        
        hStack.addArrangedSubview(field1)
        hStack.addArrangedSubview(field2)
        
        stack.addArrangedSubview(hStack)
        
        let button1 = UIButton()
        button1.setTitle("Вычесть", for: .normal)
        button1.setTitleColor(.red, for: .normal)
        button1.addTarget(self, action: #selector(btn1TouchUp), for: .touchUpInside)
        stack.addArrangedSubview(button1)
        
        res = UILabel()
        res.text = "Разница: -"
        res.numberOfLines = 0
        res.textAlignment = .center
        stack.addArrangedSubview(res)
        
        stack.addArrangedSubview(UIView())
    }
    
    @objc func btn1TouchUp() {
        guard let resStr = presenter.sum(
            num1: Int(field1.text ?? "0"),
            num2: Int(field2.text ?? "0")) else {
            res.text = "Слишком большие числа либо некорректные данные"
            return
        }
        res.text = "Разница: \(resStr)"
    }
}

final class ViewController3Presenter: NSObject {
    func sum(num1: Int?, num2: Int?) -> Int? {
        guard let num1, let num2 else { return nil }
        return num1 - num2
    }
}
