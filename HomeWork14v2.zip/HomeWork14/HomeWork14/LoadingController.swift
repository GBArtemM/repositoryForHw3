//
//  LoadingController.swift
//  HomeWork14
//
//  Created by Алексей Ильиных on 07.01.2023.
//

import Foundation
import UIKit

final class LoadingController: UIViewController {
    
    let onboardingImages: [UIImage] = [
        .init(named: "1")!,
        .init(named: "2")!,
        .init(named: "3")!
    ]
    var curImage = 2
    private var imgView = UIImageView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.hidesBackButton = true
        view.backgroundColor = .white
        
        addOnboardView()
        addLoaderView()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 6, execute: { [weak self] in
            self?.navigationController?.pushViewController(ViewController1(), animated: true)
        })
    }
    
    func addOnboardView() {
        let v = UIView()
        v.backgroundColor = .red
        v.put(on: view, paddings: .init(top: 10, left: 10, bottom: 10, right: 10))
        imgView = UIImageView()
        imgView.put(on: v, paddings: .init(top: 2, left: 2, bottom: 2, right: 2))
        imgView.layer.cornerRadius = 10
        imgView.layer.masksToBounds = true
        imgView.contentMode = .scaleAspectFill
        imgView.clipsToBounds = true
        
        nextImage()
    }
    
    func nextImage() {
        if curImage < 2 {
            curImage += 1
        } else {
            curImage = 0
        }
        imgView.image = onboardingImages[curImage]
        DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: { [weak self] in
            self?.nextImage()
        })
    }
    
    func addLoaderView() {
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 60, y: 0))
        path.addLine(to: CGPoint(x: 60, y: 0))
        path.addLine(to: CGPoint(x: 120, y: 100))
        path.addLine(to: CGPoint(x: 0, y: 100))
        path.addLine(to: CGPoint(x: 60, y: 0))
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = UIColor.black.cgColor
        shapeLayer.fillColor = UIColor.orange.cgColor
        shapeLayer.lineWidth = 3
        
        let childView = UIView()
        childView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(childView)
        childView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        childView.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        childView.widthAnchor.constraint(equalToConstant: 120).isActive = true
        childView.heightAnchor.constraint(equalToConstant: 100).isActive = true
        childView.backgroundColor = .clear
        
        childView.layer.addSublayer(shapeLayer)
        
        rotate(view: childView, aCircleTime: 5)
    }
    
    func rotate(view: UIView, aCircleTime: Double) {
        UIView.animate(withDuration: aCircleTime/2, delay: 0.0, options: .curveLinear, animations: {
            view.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi))
        }, completion: { finished in
            UIView.animate(withDuration: aCircleTime/2, delay: 0.0, options: .curveLinear, animations: {
                view.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi*2))
            }, completion: { finished in
                self.rotate(view: view, aCircleTime: aCircleTime)
            })
        })
    }
}
