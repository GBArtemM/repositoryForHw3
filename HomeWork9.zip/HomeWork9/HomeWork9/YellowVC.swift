//
//  YellowVC.swift
//  HomeWork9
//
//  Created by Алексей Ильиных on 04.01.2023.
//

import UIKit

class YellowVC: UIViewController {

    @IBAction func fromYellow(_ sender: Any) {
        let home1View = self.storyboard?.instantiateViewController(withIdentifier: "Home1") as! Item1VC
        self.navigationController?.pushViewController(home1View, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
