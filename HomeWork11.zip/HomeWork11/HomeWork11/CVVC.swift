//
//  TBVC.swift
//  HomeWork10
//
//  Created by Алексей Ильиных on 06.01.2023.
//

import Foundation
import UIKit

struct Model {
    var image: UIImage
    
    init(image: UIImage) {
        self.image = image
    }
}

final class CVVC: UIViewController {
    private lazy var tvds = TVDS(models: models)
    private var models: [Model] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.models = Array(1...10).compactMap {
                .init(image: UIImage(named: "\($0)")!)
        }
        
        view.backgroundColor = .white
        navigationItem.hidesBackButton = true
        navigationItem.title = "Collection"
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        layout.itemSize = CGSizeMake(
            UIScreen.main.bounds.width / 2,
            UIScreen.main.bounds.width / 2
        )
        let collect = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collect.register(Cell.self, forCellWithReuseIdentifier: "Cell")
        collect.dataSource = tvds
        collect.put(on: view)
    }
}

final class TVDS: NSObject, UICollectionViewDataSource {
    
    private var models: [Model] = []
    
    init(models: [Model]) {
        self.models = models
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        2 // tmp
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        models.count / 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! Cell
        cell.prepare(model: models[indexPath.row * 2 + indexPath.section])
         return cell
     }
}

final class Cell: UICollectionViewCell {
    func prepare(model: Model) {
        
        let img = UIImageView()
        img.image = model.image
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        img.layer.cornerRadius = self.frame.width / 2
        img.layer.masksToBounds = true
        img.put(on: self, paddings: .init(top: 10, left: 3, bottom: 10, right: 3))
    }
    
}
