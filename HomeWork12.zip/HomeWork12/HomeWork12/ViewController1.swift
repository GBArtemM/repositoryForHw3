//
//  ViewController1.swift
//  HomeWork12
//
//  Created by Алексей Ильиных on 06.01.2023.
//

import Foundation
import UIKit

final class ViewController1: UIViewController {
    let presenter = ViewController1Presenter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        navigationItem.hidesBackButton = true
        
        let stack = UIStackView()
        stack.axis = .vertical
        
        let button1 = UIButton()
        button1.setTitle("Сложнение", for: .normal)
        button1.setTitleColor(.red, for: .normal)
        button1.addTarget(self, action: #selector(btn1TouchUp), for: .touchUpInside)
        stack.addArrangedSubview(button1)
        
        let button2 = UIButton()
        button2.setTitle("Вычитание", for: .normal)
        button2.setTitleColor(.blue, for: .normal)
        button2.addTarget(self, action: #selector(btn2TouchUp), for: .touchUpInside)
        stack.addArrangedSubview(button2)
        
        stack.addArrangedSubview(UIView())
        
        stack.put(on: view)
    }
    
    @objc func btn1TouchUp() {
        presenter.openSumVC(on: self)
    }
    
    @objc func btn2TouchUp() {
        presenter.openDiffVC(on: self)
    }
}

final class ViewController1Presenter: NSObject {
    func openSumVC(on parent: UIViewController) {
        parent.navigationController?.pushViewController(
            ViewController2(),
            animated: true
        )
    }
    
    func openDiffVC(on parent: UIViewController) {
        parent.navigationController?.pushViewController(
            ViewController3(),
            animated: true
        )
    }
}
