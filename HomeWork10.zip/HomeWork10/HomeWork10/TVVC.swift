//
//  TBVC.swift
//  HomeWork10
//
//  Created by Алексей Ильиных on 06.01.2023.
//

import Foundation
import UIKit

struct Model {
    var title: String
    var detailSubtitle: String
}

final class TVVC: UIViewController {
    private lazy var tvds = TVDS(models: models, onSelect: onSelect)
    private var models: [Model] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.models = Array(0..<20).compactMap {
            .init(title: "Title \($0)", detailSubtitle: "Subtitle Subtitle Subtitle \($0)")
        }
        
        view.backgroundColor = .white
        navigationItem.hidesBackButton = true
        navigationItem.title = "Table"
        let table = UITableView()
        table.dataSource = tvds
        table.delegate = tvds
        table.put(on: view)
    }
    
    private func onSelect(num: Int) {
        let vc = DetailVC(model: models[num])
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

final class TVDS: NSObject, UITableViewDataSource, UITableViewDelegate {
    private var models: [Model] = []
    private var onSelect: (Int) -> Void
    
    init(models: [Model], onSelect: @escaping (Int) -> Void) {
        self.models = models
        self.onSelect = onSelect
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        models.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        let v = UIView()
        v.put(on: cell)
        let lbl = UILabel()
        lbl.text = models[indexPath.item].title
        lbl.numberOfLines = 0
        lbl.put(on: v, paddings: .init(top: 12, left: 8, bottom: 12, right: 8))
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.onSelect(indexPath.item)
    }
}
