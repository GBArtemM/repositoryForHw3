import UIKit

extension UIView {
    func put(on view: UIView, paddings: UIEdgeInsets = .zero) {
        self.translatesAutoresizingMaskIntoConstraints = false
        let stack = UIStackView()
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.layoutMargins = .init(
            top: paddings.top,
            left: paddings.left,
            bottom: paddings.bottom,
            right: paddings.right
        )
        stack.isLayoutMarginsRelativeArrangement = true
        view.addSubview(stack)
        stack.addArrangedSubview(self)
        stack.leadingAnchor.constraint(
            equalTo: view.leadingAnchor
        ).isActive = true
        stack.trailingAnchor.constraint(
            equalTo: view.trailingAnchor
        ).isActive = true
        stack.topAnchor.constraint(
            equalTo: view.topAnchor
        ).isActive = true
        stack.bottomAnchor.constraint(
            equalTo: view.bottomAnchor
        ).isActive = true
    }
}
