//
//  DetailVC.swift
//  HomeWork10
//
//  Created by Алексей Ильиных on 06.01.2023.
//

import Foundation
import UIKit

final class DetailVC: UIViewController {
    private var model: Model
    
    init(model: Model) {
        self.model = model
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        navigationItem.title = "Detail"
        let stack = UIStackView()
        stack.axis = .vertical
        stack.put(on: view)
        
        let lbl = UILabel()
        lbl.numberOfLines = 0
        lbl.text = "\(model.title)\n\(model.detailSubtitle)"
        stack.addArrangedSubview(lbl)
        stack.addArrangedSubview(UIView())
    }
}
