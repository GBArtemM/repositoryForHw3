//
//  ViewController.swift
//  HomeWork8
//
//  Created by Алексей Ильиных on 31.12.2022.
//

import UIKit

class ViewController: UIViewController {

    var count: Int = 0
    var timer = Timer()
    
    @IBOutlet weak var timerLabel: UILabel!
    
    @IBAction func startButton(_ sender: Any) {
        timer.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self,selector: #selector(timerAction), userInfo: nil, repeats: true)
        RunLoop.current.add(timer, forMode: .common)
    }
    
    @IBAction func stopButton(_ sender: Any) {
        timer.invalidate()
    }
    
    @objc func timerAction() {
        count += 1
        let time = secondsToMinutes(seconds: count)
        let timeString = makeTimeString(minutes: time.0, seconds: time.1)
        timerLabel.text = "\(timeString)"
    }
    
    func secondsToMinutes(seconds: Int) -> (Int, Int){
        return ((seconds / 60), (seconds % 60))
    }
    func makeTimeString(minutes: Int, seconds: Int) -> String {
        var timeString = ""
        timeString += String(format: "%02d", minutes)
        timeString += ":"
        timeString += String(format: "%02d", seconds)
        return timeString
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

